
#include <vector>
#include <string>
#include <iostream>
#include "ExpressionTree.hpp"

/*int main() {
    vector<string> expr; // { "+", "3", "*", "5", "2" };
    expr.push_back("+");
    expr.push_back("3");
    expr.push_back("*");
    expr.push_back("5");
    expr.push_back("2");

    ExpTree tree(expr);

    tree.printInfix();
    printf("\n");
    tree.printPrefix();

    printf("\nResult: %d", tree.eval());

    return 0;
}
*/